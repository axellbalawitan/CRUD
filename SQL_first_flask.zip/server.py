from flask_app.controller import controller1
from flask_app import app


if __name__ == "__main__":
    app.run(debug=True)


